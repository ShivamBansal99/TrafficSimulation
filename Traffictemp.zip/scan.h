#ifndef MY_HEADER
#define MY_HEADER
#include <bits/stdc++.h>
 int scan(vector< vector<int>> &spec ,vector<string> &types ,vector<vector<string>> &seconds );
#endif 